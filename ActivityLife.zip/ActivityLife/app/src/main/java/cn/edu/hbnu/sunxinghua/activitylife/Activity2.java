package cn.edu.hbnu.sunxinghua.activitylife;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class Activity2 extends Activity {
	
	/** Called when the activity is first created. */
	private static final String TAG = "ActivityLife";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main1);
        Log.e(TAG,"2-onCreate");
        Button button = (Button) findViewById( R.id.button);
        button.setText("进入Activity1");
        button.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent( Activity2.this,MainActivity.class);
				startActivity(intent);
			}
		});
    }
    
    @Override
	protected void onStart() {
		// TODO Auto-generated method stub
		 super.onStart();
		 Log.e(TAG,"2-onStart");
	}

    
    @Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		 Log.e(TAG,"2-onResume");
	}

    @Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		 Log.e(TAG,"2-onRestart");
	}
    @Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		 Log.e(TAG,"2-onPause");
	}
    @Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		 Log.e(TAG,"2-onStop");
	}
    
    @Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		 Log.e(TAG,"2-onDestroy");
	}
}