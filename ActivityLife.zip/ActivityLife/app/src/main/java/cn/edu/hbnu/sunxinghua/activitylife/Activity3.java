package cn.edu.hbnu.sunxinghua.activitylife;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class Activity3 extends Activity {
	
	/** Called when the activity is first created. */
	private static final String TAG = "ActivityLife";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        Log.e(TAG,"3onCreate");
    }
	

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		 super.onStart();
		 Log.e(TAG,"3onStart");
	}
    
	
    @Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		 Log.e(TAG,"3onResume");
	}
    
    @Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		 Log.e(TAG,"3onRestart");
	}
    @Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		 Log.e(TAG,"3onPause");
	}
    @Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		 Log.e(TAG,"3onStop");
	}
    
    @Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		 Log.e(TAG,"3onDestroy");
	}
}