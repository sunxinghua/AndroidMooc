package com.bhbnu.mooc.fileio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    TextView textView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.hello);
    }

    // File存储 - 保存文件
    public void saveFileInApplication(View view) {

        String fileName = "data.txt";
        String content = "helloworld";
        FileOutputStream fos;

        try {
            // 以追加模式创建了file.txt文件，并写入文字"保存文件到应用程序下"

            fos = openFileOutput(fileName, MODE_PRIVATE);
            fos.write(content.getBytes());
            fos.close();
            Toast.makeText(this, "保存文件成功", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            // 抛出异常
            Toast.makeText(this, "保存文件失败", Toast.LENGTH_LONG).show();
        }
    }

    // File存储 - 读取文件
    public void readFileInApplication(View view) {
        String content = "";
        FileInputStream fis;

        try {

            fis = openFileInput("data.txt");
            byte[] buffer = new byte[fis.available()];
            fis.read(buffer);
            content = new String(buffer);
            fis.close();

            textView.setText(content);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            return;
        }
    }

    // File存储 - 删除文件
    public void deleteFileInApplication() {
        this.deleteFile("file.txt");
    }
}