package cn.edu.hbnu.sunxinghua.sqlitedemo;

import cn.edu.hbnu.sunxinghua.sqlitedemo.db.DatabaseHelper;
import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

    /**
     * Called when the activity is first created.
     */
    private Button createButton;
    private Button insertButton;
    private Button updateButton;
    private Button updateRecordButton;
    private Button queryButton;
    private Button deleteButton;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //createButton = (Button) findViewById(R.id.createDatabase);
       // updateButton = (Button) findViewById(R.id.updateDatabase);
        insertButton = (Button) findViewById(R.id.insert);
        updateRecordButton = (Button) findViewById(R.id.update);
        queryButton = (Button) findViewById(R.id.query);
        deleteButton = (Button) findViewById(R.id.delete);
       // createButton.setOnClickListener(new CreateListener());
       // updateButton.setOnClickListener(new UpdateListener());
        insertButton.setOnClickListener(new InsertListener());
        updateRecordButton.setOnClickListener(new UpdateRecordListener());
        queryButton.setOnClickListener(new QueryListener());
        deleteButton.setOnClickListener(new DeleteRecordListener());
    }

    /*class CreateListener implements OnClickListener {
        @Override
        public void onClick(View v) {
            //创建一个DatabaseHelper对象
            DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);
            //只有调用了DatabaseHelper对象的getReadableDatabase()方法，或者是getWritableDatabase()方法之后，才会创建，或打开一个数据库
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Log.d("myDebug", "CreateSuccess");
        }
    }

    class UpdateListener implements OnClickListener {

        @Override
        public void onClick(View v) {
            DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);
            SQLiteDatabase db = dbHelper.getReadableDatabase();
        }

    }*/

    class InsertListener implements OnClickListener {

        @Override
        public void onClick(View v) {

            DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("name", "apple");
            values.put("price", 10);
            long id = db.insert("information", null, values);
            db.close();

            Log.d("myDebug", "InsertSuccess");
        }
    }

    //更新操作就相当于执行SQL语句当中的update语句
    //UPDATE table_name SET XXCOL=XXX WHERE XXCOL=XX...
    class UpdateRecordListener implements OnClickListener {

        @Override
        public void onClick(View arg0) {
            // TODO Auto-generated method stub
            //得到一个可写的SQLiteDatabase对象
            DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("name", "orange");
            db.update("information", values, "_id=?", new String[]{"1"});
            Log.d("myDebug", "UpdateSuccess");
            db.close();

        }
    }

    class QueryListener implements OnClickListener {

        @Override
        public void onClick(View v) {
            System.out.println("aaa------------------");


            DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            Cursor cursor = db.query("information", null, "_id=?", new
                    String[]{"1"}, null, null, null);
            boolean result = cursor.moveToNext();
            //根据列名获得列索引
            String name = cursor.getString(cursor.getColumnIndex("name"));
            System.out.println("query--->" + name);
            cursor.close();
            db.close();


            // Cursor cursor = db.query("information", new String[]{"id","name"}, "id=?", new String[]{"1"}, null, null, null);


        }
    }

    //更新操作就相当于执行SQL语句当中的update语句
    //Delet table_name WHERE XXCOL=XX...
    class DeleteRecordListener implements OnClickListener {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            //得到一个可写的SQLiteDatabase对象

            DatabaseHelper dbHelper = new DatabaseHelper(MainActivity.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            db.delete("information", "_id=?", new String[]{"1"});
            Log.d("myDebug", "DeleteSuccess");

            db.close();

        }
    }

}
